# Main window
#Label1: ENTER YOUR NAME BELOW
#Entry Widget1
#Label2: CHOOSE CALENDAR
#Button Widget: OK
#A new window displaying timer
# A new label displaying the time

from tkinter import messagebox
from tkinter import*

import os
import time
from tkcalendar import Calendar, DateEntry

from datetime import date
import time


#Call a tkinter instance


window=Tk()
window.title('Register_File')
window.attributes("-fullscreen", False) 
window.geometry('1150x700+100+10')
window.configure(bg='grey')
window.resizable(0,0)
window.overrideredirect(False)

print('C:/Users/'+str(os.getlogin())+'/Desktop/Register file1.txt')



#def clicked3():
        
      
    #cal_time=time.perf_counter()
     #Floor division for minute
    #cal_time_m=cal_time//60
    

    #a=' min'
    
    
    
        #creating a label to time display
    #lb_2.configure(text=str(cal_time_m) + str(a) ) 
    
    
    
    
    #lb_2.after(1000,clicked3)
    #window2.attributes('-topmost', True)
    #window2.mainloop()
        

#def clicked2():
    
    #global window2
    #global lb_2
    #window2=Tk()
    #window2.geometry('150x25')
    
    #window2.title('Timer')
    #lb_2=Label(window2,text='',font=('times',15,'bold'),bg='red')
    #lb_2.pack(padx=5,fill=BOTH,expand=1)
    
    #clicked3()
try:
    
    path=os.mkdir('C:/Users/'+str(os.getlogin())+'/Desktop/Register file')
    root2=Tk()
    root2.title("WELCOME")
    root2.geometry('500x250+100+10')
    

    label1=Label(root2,text="Please close both windows and Open again",font=('times',16,'bold'))
    label1.pack(pady=20)
    #label2=Label(root2,text="Design: Vijith",font=('times',10,'bold'))
    #label2.pack(pady=20)
    root2.attributes('-topmost',True)
    
   
   
    root2.mainloop()

except:
    

        

    def clicked():
        
        
        #bt_3.config(event='DISABLED')
        global get_e1
        global get_e3
        get_e1=e1.get() # getting the entry file
        get_e2=e2.get() # getting the entry file
        get_e3=e3.get()
        #Calculating the length of the entry
        entry_length1=len(get_e1)
        entry_length2=len(get_e2)
        entry_length3=len(get_e3)
        #if condition

        if entry_length1==0:

            lb_7.configure(text='Error: Entry field cannot be empty')
        elif entry_length2==0:
            lb_7.configure(text='Error: Entry field cannot be empty')
        elif entry_length3==0:
            lb_7.configure(text='Error: Entry field cannot be empty')
            

        else:
            get_cal=cal.get() # getting the calendar
            
            get_time=time.strftime('%H:%M:%S') # getting the time
            #username=os.getlogin()
            
            
            print("the path2 is",path2)
            #file_path=(fr'C:\Users\{os.getlogin()}\Desktop\Register file.txt')
            file_create=open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file/Register file.txt','a')
            os.system('attrib +h '+path+'Register file.txt')
            file_create.write(get_e1+'\t\t\t'+get_e2+'\t'+get_e3+'\t\t'+get_cal+'\t'+get_time+'\n')
            file_create.close()
        
            messagebox.showinfo('Message title',get_e1+ ' ,Thank you for the entry!')    
            e1.delete(first=0,last=len(e1.get()))
            e2.delete(first=0,last=len(e2.get()))
            e3.delete(first=0,last=len(e3.get()))
            lb_7.configure(text='')
            
        #
            #e1.configure(state=DISABLED)
            #window.destroy()
            #clicked2()

    def clicked2():

        global get_e1
        global get_e3
        get_e1=e1.get() # getting the entry file
        get_e2=e2.get() # getting the entry file
        get_e3=e3.get()
        #Calculating the length of the entry
        entry_length1=len(get_e1)
        entry_length2=len(get_e2)
        entry_length3=len(get_e3)
        #if condition

        if entry_length1==0:

            lb_7.configure(text='Error: Entry field cannot be empty')
        elif entry_length2==0:
            lb_7.configure(text='Error: Entry field cannot be empty')
        elif entry_length3==0:
            lb_7.configure(text='Error: Entry field cannot be empty')

        else:
            
            get_cal=cal.get() # getting the calendar
            get_time=time.strftime('%H:%M:%S') # getting the time
            

            #file_path='Register file.txt'
            os.system('attrib +h '+'C:/Users/'+str(os.getlogin())+'/Desktop/Register file.txt')
            with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file/Register file.txt','a')as file_create:
                file_create.write(get_e1+'\t\t\t'+get_e2+'\t'+get_e3+'\t\t'+get_cal+'\t'+get_time+'\n')

            file_create.close()
            
            lb_7.configure(text='')

            #filepath='registerfile1.txt'
            #filepath2='registerfile2.txt'
            names=e1.get()
            with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file1.txt','a')as f:
               f.write(names+'\n')

            tools=e2.get()

            with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file2.txt','a')as f1:
                f1.write(tools+'\n')

            messagebox.showinfo('Message',get_e1+ ' , kindly "Return" the '+get_e2+' after use. Thank You!')    

            e1.delete(first=0,last=len(e1.get()))
            e2.delete(first=0,last=len(e2.get()))
            e3.delete(first=0,last=len(e3.get()))

            f.close()
            f1.close()

           



    def clicked3():
        
        key1=[]
        value1=[]
        global root
        root=Tk()
        root.geometry('500x150+100+10')
        root.config(bg='white')
        root.title("Return_Form")
        root.resizable(0,0)
        root.overrideredirect(False)

        #filepath='registerfile1.txt'
        #filepath2='registerfile2.txt'
        with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file1.txt','r')as f:
            line1=f.readlines()
            for line in line1:
                key1.append(line)
                print(key1)

        with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file2.txt','r')as f1:
            line2=f1.readlines()
            for line in line2:
                value1.append(line)

        global var
        global var2
        var=StringVar(root)
        
        var.set(key1[0])
        option=OptionMenu(root,var,*key1)
        option.config(width=15)
        option.pack(side='left',padx=50)
        var2=StringVar(root)
        instrument=(value1)
        print(instrument)
        var2.set(value1[0])
        option2=OptionMenu(root,var2,*value1)
        option2.config(width=15)
        option2.pack(side='right',padx=50)
        bt_win2=Button(root,text='CLEAR',width=10,font=('times',15,'bold'),command=clicked4)
        bt_win2.place(x=185,y=100)
        root.attributes('-topmost', True)
        root.mainloop()


    def clicked4():
        name2=var.get()
        print(name2)
        tool2=var2.get()

        
        
        #filepath='file1.txt'
        #filepath2='file2.txt'


        
        with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file1.txt','r')as f:
            

            
            line_delete=f.readlines()
            num_lines=len(line_delete)

            if num_lines==1:
                messagebox.showinfo('Warning!',"Close the window if your 'Name' is not in the 'List'")
                root.attributes('-topmost', True)

            else:

                with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file1.txt','w')as f:
                    for line in line_delete:
                       
                        if line != name2:
                            f.write(line)
                    f.truncate()

        with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file2.txt','r')as f1:
                    line_delete1=f1.readlines()
                    num_lines2=len(line_delete1)
                    if num_lines==1:
                        #messagebox.showinfo('Warning!',"Close the window if your 'Name' is not in the 'List'")
                        root.attributes('-topmost', True)

                    else:
                    

                        with open('C:/Users/'+str(os.getlogin())+'/Desktop/Register file2.txt','w')as f1:
                            for line1 in line_delete1:
                                if line1!=tool2:
                                    f1.write(line1)
                            f1.truncate()
                            root.destroy()

                                
                    
                            
        f.close()
        f1.close()
        
    def clicked5():

        messagebox.showinfo('Message','Thank You for the Entry!')
        
    #Label 4

    lb_7=Label(window,text='',bg='grey',fg='orange')
    lb_7.pack(pady=5)    

    #Adding the first label
    Lab_0=Label(window,text="Equipment Utilization Form", font=('times',40,'bold'),bg='grey',fg='Black')
    Lab_0.pack(pady=10,expand=0)

        

    #Adding the first label
    Lab_1=Label(window,text='Enter Your Name', font=('times',20,'bold'),bg='grey',fg='white')
    Lab_1.pack(fill=BOTH,expand=0)

    #Adding an entry widget
    e1=Entry(window,width=40)
    e1.pack(pady=10)
    e1.focus()



    #Adding the first label
    Lab_3=Label(window,text='Enter the Name of Your Lab', font=('times',20,'bold'),bg='grey',fg='white')
    Lab_3.pack(fill=BOTH,expand=0)

    #Adding an entry widget
    e3=Entry(window,width=40)
    e3.pack(pady=10)
    e3.focus()

    #Adding the first label
    Lab_5=Label(window,text='Enter the Name of Instrument/ Chemical/ Facility', font=('times',20,'bold'),bg='grey',fg='white')
    Lab_5.pack(fill=BOTH,expand=0)

    #Adding an entry widget
    e2=Entry(window,width=40)
    e2.pack(pady=10)
    e2.focus()

    #Date
    #Adding a second label
    Lab_2=Label(window,text='Choose the Date',font=('times',20,'bold'),bg='grey',fg='white')
    Lab_2.pack(pady=5)

    #Adding a calendar picker
    cal = DateEntry(window,width=15,year=2020,month=2,day=1,borderwidth=1,selectbackground='gray80',
                     selectforeground='black',
                     normalbackground='white',
                     normalforeground='black',
                     background='gray90',
                     foreground='black',
                     bordercolor='gray90',
                     othermonthforeground='gray50',
                     othermonthbackground='white',
                     othermonthweforeground='red',
                     othermonthwebackground='white',
                     weekendbackground='white',
                     weekendforeground='black',
                     headersbackground='white',
                     headersforeground='gray70')
                     
    cal.pack(pady=10)

    #Adding the first label
    Lab_5=Label(window,text='Are you carrying the Instrument/ Chemical outside of the lab?', font=('times',10,'bold'),bg='blue',fg='white')
    Lab_5.pack(pady=10,fill=BOTH,expand=0)



    #Getting current date

    today=date.today()
    b=today.strftime('%Y:%M')
    year,month=b.split(":")
    y=int(month[0])
    print(y)

    #Adding a button widget
    bt_1=Button(window,text="Yes",font=('times',10,'bold'),command=clicked2)
    #bt_1.place(height=30,x=500,y=490)
    bt_1.pack(pady=5)
    

    #Adding a button widget
    bt_2=Button(window,text="No!",font=('times',10,'bold'),command=clicked)
    #bt_2.place(height=30,x=620,y=490)
    bt_2.pack()

    #Adding the first label
    Lab_6=Label(window,text="Click 'Yes' only when return ( only if it was carried outside of the Lab)", font=('times',10,'bold'),bg='red',fg='white')
    Lab_6.pack(pady=10,fill=BOTH,expand=0)

    #Adding a button widget
    #bt_3=Button(window,text="RETURN",font=('times',15,'bold'),command=clicked3)
    #bt_3.place(x=525,y=620)

    #Adding a button widget
    bt_3=Button(window,text="Yes",font=('times',10,'bold'),command=clicked3)
    #bt_3.place(height=30,x=500,y=600)
    bt_3.pack(pady=5)

    #Adding a button widget
    bt_4=Button(window,text="No!",font=('times',10,'bold'),command=clicked5)
    #bt_4.place(height=30,x=620,y=600)
    bt_4.pack()


    #Adding a button widget
    #bt_4=Button(window,text='OK',command=clicked)
    #bt_4.pack(pady=5)

    #When the OK Button is pressed
    # 1. Create a text file in a specific folder
    # 2. Create a text file
    # 3. Append entry , Date, and time
    # 4. Open a time



    window.attributes('-topmost', True)
    #def disable_event():
        #pass

    #window.protocol("WM_DELETE_WINDOW", disable_event)

       
    window.mainloop()

